<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'header.php';?>
<?php include 'menu.php';?>
<?php
if(isset($_POST["btnsave"]))
{
  extract($_POST);
  pg_query("insert into tbluser(uname,upass,email)Values('$txtname','$txtpass','$txtemail')");

}


?>
<br>

 <form method="post">
  <TABLE class="table-condensed">
    <Tr>
      <Td>
      <b> <h3> Name</h3></b>
      </Td>
      <td>
        <input type="text" name="txtname" class="form-control">
      </td>
    </Tr>
     <Tr>
      <Td>
     <b> <h3>Email</h3></b>
      </Td>
      <td>
        <input type="text" name="txtemail" class="form-control">
      </td>
    </Tr>
     <Tr>
      <Td>
      <b> <h3>Password</h3></b>
      </Td>
      <td>
        <input type="password" name="txtpass" class="form-control">
      </td>
    </Tr>
    <tr>
      <Td>
        <input type="submit" class="btn btn-success" name="btnsave" value="Register">
      </Td>
    </tr>
  </TABLE>
</form>

<?php include 'footer.php';?>
</body>
</html>

