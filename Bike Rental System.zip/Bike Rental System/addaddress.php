<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>
<?php
if(isset($_POST["btnsave"]))
{
extract($_POST);
pg_query("insert into tbladdress(address,uid)values('$txtaddress','".$_SESSION["uid"]."')");
header("location:chooseaddress.php");

}

?>
<div class="content">
<form method="post">
<table>
<Tr>
<Td>
Add Address
</td>
<td>
<textarea name="txtaddress"></textarea>
</td>
</tr>
<Tr>
<Td>
<input type="submit" name="btnsave">
</td>
</tr>
</table>
</form>
</div>
<?php include "footer.php";?>
</body>
</html>
