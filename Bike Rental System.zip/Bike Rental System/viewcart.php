<html>
<head>
<title>
Cart
</title>

<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>



<table class="table">
<Tr>
<Td>
	<span style="color: black;">
Bike Name
</span>
</td>
<td>
	<span style="color: black;">
Rent Price
</span>
</td>
<td>
	<span style="color: black;">
Discount Price
</span>
</td>
<td>
	<span style="color: black;">
Quantity
</span>
</td>
<td>
	<span style="color: black;">
Total
</span>
</td>
</tr>
<?php
$q=pg_query("select * from tblcart,tblbike,tbluser where tbluser.uid=tblcart.uid and tblcart.pid=tblbike.pid and tbluser.uid='".$_SESSION["uid"]."' and status=0");
while($r=pg_fetch_array($q))
{
?>
<Tr>
<Td><span style="color: black;">
<?php echo $r['pname'];?></span>
</td>
<td>
	<span style="color: black;">
<?php echo $r['pprice'];?></span>
</td>
<Td><span style="color: black;">
<?php echo $r['qty'];?></span>
</td>
<td>
<?php 
echo $total=$r['pdprice']*$r['qty'];
$z+=$r['pdprice']*$r['qty'];
?>

</td>
<Td>
<a href="remove.php?id=<?php echo $r['cartid'];?>">Remove From Cart</a>
</td>
</tr>
<?php
}
?>
<Tr>
<Td><span style="color: black;">
Total
</span>
</td>
<Td><span style="color: black;">
<?php echo $z;?>
</span>
</td>
</tr>
<tR>
<td colspan=4 align=center>
<a href="chooseaddress.php">Choose Address</a>
</table>

</div>
<?php include "footer.php";?>
</body>
</html>
