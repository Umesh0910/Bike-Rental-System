<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>
<?php include 'upload.php';?>
<?php

if(isset($_POST["btnsave"]))
{
	extract($_POST);
	$z=fileupload("images");
	pg_query("insert into tblbike(pname,pprice,pdprice,pstock,pimage,cid)values('$txtpname','$txtpprice','$txtpdprice','$txtstock','$z','$cmbcategory')");
	
}
?>
<form method="post" enctype="multipart/form-data">
	<table class="table">
		<tr>
			<td>
				Choose Category
			</td>
			<Td>
				<select name="cmbcategory" class="form-control">

					<?php 
					$q=pg_query("select * from tblcategory");
					while ($r=pg_fetch_array($q)) {
						?>
					<option value="<?php echo $r['cid'];?>"><?php echo $r["cname"];?></option>
					<?php
					}
					?>

					
					
				</select>


			</Td>
		</tr>
        
		<Tr>
			<Td>
				Bike Name
			</Td>
			<td>
				<input type="text" class="form-control" name="txtpname">
			</td>
		</Tr>
		<Tr>
			<Td>
				Bike Price
			</Td>
			<td>
				<input type="text" class="form-control" name="txtpprice">
			</td>
		</Tr>
		<Tr>
			<Td>
				Bike rent Discount Price
			</Td>
			<td>
				<input type="text" class="form-control" name="txtpdprice">
			</td>
		</Tr>
		<Tr>
			<Td>
				Bike Image
			</Td>
			<td>
				<input type="file" class="form-control" name="img">
			</td>
		</Tr>
		<Tr>
			<Td>
				Bike Stock
			</Td>
			<td>
				<input type="number" class="form-control" name="txtstock">
			</td>
		</Tr>
		<Tr>
			<Td>
				<input type="submit" name="btnsave"  class="btn btn-success" value="Add Bike">
			</Td>
		</Tr>
	</table>
<?php include 'footer.php';?>
</body>
</html>
