 <!-- Navigation
    ==========================================-->
    <nav id="tf-menu" class="navbar navbar-default navbar-fixed-top" style="background-color: black;">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">BIKEWALE</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">

       <li><a href="index.php" ><b>Home</b></a></li>
      <?php if($_SESSION["email"]==null)
      {
      ?>
       <li><a href="register.php"><b>Register</b></a></li>
       <li><a href="login.php" ><b>Login</b></a></li>
            <?php 
            }
            else
            {
              ?>
        <li><a href="viewcategory.php"><b>Categories</b></a></li>
        <li><a href="bikes.php"       ><b>Bikes</b></a></li>
        <li><a href="viewcart.php"    ><b>View Cart</b></a></li>
       
        <li><a href="myorders.php"    ><b>My Orders</b></a></li>
        <li><a href="logout.php"      ><b>Logout</b></a></li>

            <?php
            }
            ?>
            

          
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>

    
 <br>
 <br>
 <br>
 <br>
