<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>
<br>
<br>
<table class="table">
<tr>
<Td><span style="color: black;">
Name
</span>
</td>
<td>
	<span style="color: black;">
<?php echo $_SESSION["uname"];?>
</span>
</td>
</tr>
<tr>
<td>
	<span style="color: black;">
Address
</span>
</td>
<td><span style="color: black;">
<?php echo  $_GET["id"];?></span>
</td>
</tr>

</table>
<table class="table">

<Tr>
<Td>
	<span style="color: black;">
Food Name
</span>
</td>
<Td>
	<span style="color: black;">
Food price
</span>
</td>
<td>
	<span style="color: black;">
Discount Price
</span>
</td>
<td>
	<span style="color: black;">
QTY
</span>
</td>
<td>
	<span style="color: black;">
Total
</span>
</td>
</tr>
<?php
$q=pg_query("select * from tblcart,tblbike,tbluser where tbluser.uid=tblcart.uid and tblcart.pid=tblbike.pid and tbluser.uid='".$_SESSION["uid"]."'");
while($r=pg_fetch_array($q))
{
?>
<Tr>
<Td><span style="color: black;">
<?php echo $r['pname'];?></span>
</td>
<td><span style="color: black;">
<?php echo $r['pprice'];?></span>
</td>
<td><span style="color: black;">
<?php echo $r['pdprice'];?></span>
</td>
<Td><span style="color: black;">
<?php echo $r['qty'];?></span>
</td>
<td>
<?php 
echo $total=$r['pdprice']*$r['qty'];
$z+=$r['pdprice']*$r['qty'];
?>

</td>
</tr>
<?php
}
?>
<Tr>
<Td>
	<span style="color: black;">
Total
</span>
</td>
<Td>
<span style="color: black;">	
<?php echo $z;?>
</span>
</td>
</tr>
</table>
<?php
if(isset($_POST["btnbill"]))
{
extract($_POST);
pg_query("update tblcart set status=1 where uid='".$_SESSION["uid"]."'");

}
?>
<form method="post">
<table>
<Tr>
<TD>
	<div class='pm-button'><a href='https://www.payumoney.com/paybypayumoney/#/5CC80A3E972D8A29D10953FBC2EAC5DE'><img src='https://www.payumoney.com/media/images/payby_payumoney/new_buttons/21.png' /></a></div> 
<input type="submit" name="btnbill" value="Pay Bill">
</td>
</tr>
</table>
</form>
</div>
<?php include "footer.php";?>
</body>
</html>
