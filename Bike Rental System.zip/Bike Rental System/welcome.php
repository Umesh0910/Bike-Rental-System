<!DOCTYPE html>
<br>
<br>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'header.php';?>
<?php include 'menu.php';?>

Welcome <?php echo $_SESSION["uname"];?>
<?php include 'footer.php';?>
</body>
</html>
