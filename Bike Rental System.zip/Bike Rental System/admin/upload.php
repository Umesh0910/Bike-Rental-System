<?php
function fileupload($path)
{
$img=rand(1000,100000)."-".$_FILES['img']['name'];
$pic_loc=$_FILES['img']['tmp_name'];
$folder=$path."/";
if (move_uploaded_file($pic_loc,$folder.$img)) {
return $folder.$img;

}
}
?>
