<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>
<?php 
if(isset($_POST["btnstatus"]))
{
extract($_POST);
pg_query("update tblcart set status='$cmbstatus' where cartid=".$_GET["id"]);

}
?>
<div class="content">
<form method="post">
<table>
<Tr>
<Td>
<select name="cmbstatus">
<option value=1>Order Placed</option>
<option value=2>Order Confirmed</option>
<option value=3>Arriving Today</option>
<option value=4>Delivered</option>
<option value=5>Canceled</option>
</select>
</td>
</tr>
<tr>
<td>
<input type="submit" name="btnstatus">
</tD>
</tR>
</table>
</form>
</div>
<?php include "footer.php";?>
</body>
</html>
