<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'header.php';?>
<?php include 'menu.php';?>
<?php
if(isset($_POST["btnlogin"]))
{
  extract($_POST);
 $q=pg_query("select * from tbluser where email='$txtemail' and upass='$txtpass'");
 if(pg_num_rows($q)>0)
 {
  $_SESSION["email"]=$txtemail;
  $q1=pg_query("select * from tbluser where email='".$_SESSION["email"]."'");
  $r1=pg_fetch_array($q1);
  $_SESSION["uid"]=$r1["uid"];
  $_SESSION["uname"]=$r1["uname"];
  
  ?>
  <script type="text/javascript">
    window.location.href="welcome.php";
  </script>
  <?php
 }
 else
 {
  echo "Invalid Credentials";
 }

}

?>
<br>
 <form method="post">
  <TABLE class="table-condensed">
   <Tr>
      <Td>
        Email
      </Td>
      <td>
        <input type="text" name="txtemail" class="form-control">
      </td>
    </Tr>
     <Tr>
      <Td>
        Password
      </Td>
      <td>
        <input type="password" name="txtpass" class="form-control">
      </td>
    </Tr>
    
    <tr>
      <Td>
        <input type="submit" class="btn btn-success" name="btnlogin" value="Login">
      </Td>
    </tr>
  </TABLE>
</form>

<?php include 'footer.php';?>
</body>
</html>