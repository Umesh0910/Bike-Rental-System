<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<center>
<?php
if(isset($_POST["btnlogin"]))
{
extract($_POST);
if($txtname=="admin" && $txtpass=="admin")
{
header("location:addcategory.php");
}
}


?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<b><b><h1>Admin Login</h1><b><b>
<br>

<div class="content">
<form method="post">
<table>
<TR>
<Td>
<b>Enter Name</b>
</tD>
<td>
<input type="text" name="txtname">
</td>
</tr>
<TR>
<Td>
<b>Enter Password</b>
</tD>
<td>
<input type="password" name="txtpass">
</td>
</tr>
<Tr>
<td>
        <input type="submit" class="btn btn-success" name="btnlogin" value="Login">
</td>
</tr>
</table>
</form>

</div>
<?php include "footer.php";?>
</center>
</body>
</html>
