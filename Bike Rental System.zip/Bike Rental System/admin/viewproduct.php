<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>
<table class="table">
	<tr>
        <td>
			<b><h3>Product image </h3></b>
		</td>
		<td>
			<b><h3>Product Name</h3></b>
		</td>
		<td>
			<b><h3>Product Price</h3></b>
		</td>
		<td>
			<b><h3>Product Discount Price</h3></b>
		</td>
		<td>
			<b><h3>Product Stock</h3></b>
		</td>
	</tr>
<?php
$q=pg_query("select * from tblbike");
while ($r=pg_fetch_array($q)) {
	?>
	<tr>
		<Td><img src=<?php echo $r["pimage"];?> height="200px" width="200px"></Td>
		<Td><?php echo $r["pname"];?></Td>
		<Td>&#8377;<strike><?php echo $r["pprice"];?></strike>/-</Td>
		<Td>&#8377;<?php echo $r["pdprice"];?>/-</Td>
		<Td><?php echo $r["pstock"];?></Td>
	</tr>
	<?php
}
?>
</table>

<?php include 'footer.php';?>
</body>
</html>
