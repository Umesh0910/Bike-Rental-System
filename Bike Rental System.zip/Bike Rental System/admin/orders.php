<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>

<div class="content">
<table class="table">
<Tr>
<Td>
user Name
</td>
<Td>
Product Name
</td>
<td>
Discount Price
</td>
<td>
QTY
</td>
<td>
Total
</td>
</tr>
<?php
$q=pg_query("select * from tblcart,tblbike,tbluser where tbluser.uid=tblcart.uid and tblcart.pid=tblbike.pid and status=1");
while($r=pg_fetch_array($q))
{
?>
<Tr>
<Td>
<?php echo $r['uname'];?>
</td>
<Td>
<?php echo $r['pname'];?>
</td>
<td>
<?php echo $r['pdprice'];?>
</td>
<Td>
<?php echo $r['qty'];?>
</td>
<td>
<?php 
echo $total=$r['pdprice']*$r['qty'];
$z+=$r['pdprice']*$r['qty'];
?>

</td>
<Td>
<a href="updatestatus.php?id=<?php echo $r['cartid'];?>">Update</a>
</td>
</tr>
<?php
}
?>
<Tr>
<Td>
Total
</td>
<Td>
<?php echo $z;?>
</td>
</tr>
</table>

</div>
<?php include "footer.php";?>
</body>
</html>
