<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>
<table class="table">
	<tr>
		<td>
			Category Name
		</td>
	</tr>
<?php
$q=pg_query("select * from tblcategory");
while ($r=pg_fetch_array($q)) {
	?>
	<tr>
		<Td><?php echo $r["cname"];?></Td>
	</tr>
	<?php
}
?>
</table>

<?php include 'footer.php';?>
</body>
</html>