<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>
<?php

if(isset($_POST["btnsave"]))
{
	extract($_POST);
	pg_query("insert into tblcategory(cname)values('$txtname')");

}
?>
<form method="post">
	<table class="table">
		<Tr>
			<Td>
				Category Name
			</Td>
			<td>
				<input type="text" class="form-control" name="txtname">
			</td>
		</Tr>
		<Tr>
			<Td>
				<input type="submit" name="btnsave" value="Add Category">
			</Td>
		</Tr>
	</table>
<?php include 'footer.php';?>
</body>
</html>
