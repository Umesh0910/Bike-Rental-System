<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>
<br>


<a href="addaddress.php">Add Address</a>
<table class="table">
<?php
$q=pg_query("select * from tbladdress where uid='".$_SESSION["uid"]."'");
while($r=pg_fetch_array($q))
{
?>
<Tr>
<Td>
<?php echo $r['address'];?>
</td>
<Td>
<a href="bill.php?id=<?php echo $r['address'];?>">Select</a>
</td>
</tr>
<?php
}
?>
</table>
</div>
<?php include "footer.php";?>
</body>
</html>
