<!DOCTYPE html>
<html>
<head>
	<title></title>
		<?php include 'head.php';?>
</head>
<body>
		<?php include 'menu.php';?>

    <div id="tf-home" class="text-center">
        <div class="overlay">
            <div class="content">
                <h1>Welcome on <strong><span class="color">BIKEWALE</span></strong></h1>
                <p class="lead">We are a digital agency with <strong>years of experience</strong> and with <strong>extraordinary people</strong></p>
                    <a href="#" class="fa fa-angle-down page-scroll"></a>
            
            </div>
        </div>
    </div>
 <?php include 'footer.php';?>
