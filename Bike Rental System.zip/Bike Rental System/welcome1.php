<!DOCTYPE html>

<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>

 <div id="tf-home" class="text-center">
        <div class="overlay">
            <div class="content">
                <b><h1>Welcome <strong><span class="color"> <?php echo $_SESSION["uname"];?>!</span></strong></h1></b>
                <p class="lead"><b><b><B>Tired of getting perfect vehicle on rent?<strong>Let us help you..!</strong> Click on <strong>Get Now</strong></p></B></b></b>
                    <a href="bikes.php" class="btn btn-info"><b>Get Now</b></a>
               
            
            </div>
        </div>
    </div>


<?php include 'footer.php';?>
</body>
</html>
