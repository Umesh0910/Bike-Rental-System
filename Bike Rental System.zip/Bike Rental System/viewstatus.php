<html>
<head>
<title>
</title>
<link rel="stylesheet" href="progress.css">
<?php include "head.php";?>
</head>
<body>
<?php include "header.php";?>
<?php include "menu.php";?>

<font size="10"><center>Your Order

<?php
$q=pg_query("select * from tblcart where cartid=".$_GET["id"]);
$r=pg_fetch_array($q);
$ustatus=$r['status'];

if($ustatus==1)
{
?>

is placed..!
</div>
<?php
}

if($ustatus==2)
{
?>

is confirmed..!
</div>

<?php
}

if($ustatus==3)
{
?>

is arriving today..!
<div class="w3-grey" style="height:24px;width:75%"></div>
</div>

<?php
}

if($ustatus==4)
{
?>


is delivered...!
  <div class="w3-grey" style="height:24px;width:100%"></div>
</div>

<?php
}

if($ustatus==5)
{
?>


is cancelled....!
  <div class="w3-grey" style="height:24px;width:100%"></div>
</div>

<?php
}


?></center>
</font>

</div>
</div>
<?php include "footer.php";?>
</body>
</html>
