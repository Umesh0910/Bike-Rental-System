<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'menu.php';?>
      <center><div class="col-md-6">
<table class="table">
	<tr>
		<td>
			<center><font size="15">Categories</font>

		</td>
	</tr>
<?php
$q=pg_query("select * from tblcategory");
while ($r=pg_fetch_array($q)) {
	?>
	<tr>
  
		<Td><a href="viewproduct.php?id=<?php echo $r['cid'];?>"><font size="6"><?php echo $r["cname"];?></font></a></Td>
</div>
</tr>
	<?php
}
?></center>
</table>
</div></center>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>



<?php include 'footer.php';?>
</body>
</html>
