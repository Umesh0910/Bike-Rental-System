<html>
<head>
<title>
</title>
<?php include "head.php";?>
</head>
 
<body>
<?php include "header.php";?>

<div class="row" >
	<div class="col-md-6">
<?php include "menu.php";?>
<div class="content">
<?php
if(isset($_POST["btnadd"]))
{
extract($_POST);
if($_SESSION["email"]==null)
{
header("location:login.php");
}
else
{
$qq=pg_query("select * from tblbike where pid=".$_GET["id"]);
$rr=pg_fetch_array($qq);
$dstock=$rr["pstock"];
$nstock=$dstock-$cmbqty;
if($nstock>0)
{
pg_query("update tblbike set pstock='$nstock' where pid=".$_GET["id"]); 
pg_query("insert into tblcart(pid,uid,qty,status)values('".$_GET["id"]."','".$_SESSION["uid"]."','$cmbqty',0)");
}
else
{
?>
<script>
alert('OUT OF STOCK');
</script>
<?php
}
}
}
$q=pg_query("Select * from tblbike where pid=".$_GET["id"]);
while($r=pg_fetch_array($q))
{
extract($_POST);
?>
<form method="post">
<table class=table>
<TR>
<TD colspan=2 align=center>
	<img src="admin/<?php echo $r['pimage'];?>" height=500px>
</TD>
</TR>

<Tr>
<Td>
Bike name</Td><td>
<?php echo $r["pname"];?>
</td>
</tr>
<Tr>
<Td>
Rent Price</Td><td>
<strike><?php echo $r["pprice"];?></strike>
</td>
</tr>
<Tr>
<Td>
Discount Rent Price
</Td>
<Td><?php echo $r["pdprice"];?>
</td>
</tr>
<Tr>

<Tr>
<Td>
Stock
</Td>
<Td><?php echo $r["pstock"];?>
</td>
</tr>

<Td>
Quantity
</Td>
	
<td>
<select name="cmbqty">
<option value=1>1</option>
<option value=2>2</option>
<option value=3>3</option>
</select>
</td>
</tr>
<TR>
<Td>
<input type="submit" name="btnadd" class="btn btn-success" value="Add To Cart">
</tD>
</tr>
</table>
</form>
<?php
}
?>
</div>
</div>
</div>
<?php include "footer.php";?>
</body>
</html>
