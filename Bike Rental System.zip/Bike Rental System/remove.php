<?php
include("head.php");
pg_query("delete from tblcart where cartid=".$_GET["id"]);
header("location:viewcart.php");

?>

