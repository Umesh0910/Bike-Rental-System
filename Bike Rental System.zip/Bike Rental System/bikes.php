<!DOCTYPE html>
<br>

<html>
<head>
	<title></title>
	<?php include 'head.php';?>
</head>
<body>
<?php include 'header.php';?>
<?php include 'menu.php';?>
<div class="row">
<?php
$q=pg_query("select * from tblbike");
while ($r=pg_fetch_array($q)) 
{
	?>
	<div class="col-md-4">
	<table class="table">

	<tr>
		<Td colspan=2 align=center><img src="admin/<?php echo $r['pimage'];?>" height="300px" width="300px"></Td>
	</tr>
	<tr>
		<td>Bike Name</td>
		<Td><?php echo $r["pname"];?></Td>
	</tr>
	<tr>	
		<td>Renting price</td>
		<Td>&#8377;<strike><?php echo $r["pprice"];?></strike>/-</Td>
	</tr>	
	<tr>	
		<td>Discount Price</td>
		<Td>&#8377;<?php echo $r["pdprice"];?>/-</Td>
	
	</tr>
	<tr>
		<Td colspan=2 align=center>
			<a href="viewdetails.php?id=<?php echo $r['pid'];?>"><input type="button" name="" value="View Details" class="btn btn-primary"> </a>
		</Td>
	</tr>
	</table>
</div>
	<?php
}
?>
</div>
<?php include 'footer.php';?>
</body>
</html>
